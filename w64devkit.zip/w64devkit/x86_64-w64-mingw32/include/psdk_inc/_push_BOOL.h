#pragma push_macro("BOOL")
#undef BOOL
#define BOOL WINBOOL

